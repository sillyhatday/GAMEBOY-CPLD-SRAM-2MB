module mbc5_4mb_v0.1 (
        // Variables
        reset, 
        clock,
        inputAddress, inputData, inputCE, inputWR, inputRD,
        highAddress, ramCE);

        // Inputs
        input reset;                // Assign input pin for reset
        input clock;                // Assign input pin for clock
        input [3:0] inputAddress;   // a15 - a12 [3:0] is a VECTOR 4-bits, 3, 2, 1, 0 - 4 input pins
        input [6:0] inputData;      // d6 - d0 [6:0] is a VECTOR 7 bits - 7 input pins
        input inputCE;              // Chip enable input
        input inputRD;              // Read enable input
        input inputWR;              // Write enable input

        // Outputs / Registers
        output [7:0] highAddress;   // a20 - a13 8 output pins
        reg [7:0] highAddress;      // 8 bit register

        reg [7:0] romBank;          // a20 - a13 reg is used to store an 8-bit register
        reg [1:0] ramBank;          // a14 - a13 [1:0] is the string size, just 2 bits register
        reg ramEnabled;             // 1 bit register

        output ramCE;               // RAM chip enable output
        reg ramCE;                  // 1 bit register

        reg mbc1Detect303FOn;       // Single bit register 1 or 0
        reg mbc1Detected607F;       // Single bit register 1 or 0
        reg mbc3or5Locked;          // Single bit register 1 or 0

        // ROM a0-a13 straight through, a14-a21 from CPLD highAddress [1:8]
        // FRAM a0-a12 straight through, a13-a14 from CPLD highAddress [0:1]
        // input RD, WR, CS straight through to ROM
        // input RD, WR, straight through to RAM, CE handled by CPLD
        // romCE to A15

        // Function below to reset all registers on CPU reset signal
        always @ (reset or clock or inputCE or inputRD or inputWR) begin
            if (!reset) begin
                highAddress <= 8'b0;         // Set highAddress 8 bit register to binary 0
                romBank <= 8'b1;             // Set romBank 8 bit register to binary 1
                ramBank <= 2'b0;             // Set ramBank 2 bit register to binary 0
                ramEnabled <= 1'b0;          // Set ramEnabled 1 bit register to binary 0
                ramCE <= 1'b1;               // Set ramCE 1 bit register to binary 1
                mbc1Detect303FOn <= 1'b0;    // Set register to 0
                mbc1Detected607F <= 1'b0;    // Set register to 0
                mbc3or5Locked <= 1'b0;       // Set register to 0
            end
            else begin
                // *** ROM Functions ***
                // Only pass through on 0x0000-7FFF if reading or writing flash
                // Below is used for writing data to the ROM (flash chip) in FlashGBX
                if (inputAddress <= 4'd7 && (!inputRD || !inputWR)) begin   // ! inverts the value 1  is 0 and 0 is 1 || is OR
                    if (inputAddress <= 4'd3) begin     // 0x0000-3FFF, Bank 0 always
                        highAddress <= 8'b0;            // All set all address pins to 0
                    end
                    else begin
                        highAddress <= (romBank << 1);  // Start at a14 for ROM << shift operator
                    end
                end
                
                /* This function is used to write the ROM (flash chip) bank number to the CPLD */
                // 0x2000-3FFF - 4MB - 256 banks - 8MB uses 0x3000-3FFF for 9th bit - should never be an issue
                // Low 8 bits of ROM Bank Number (Write Only) with little MBC1 detection hack
                if (((inputAddress == 4'd2) || (inputAddress == 4'd3 && mbc1Detect303FOn)) && !inputWR && inputRD && inputCE) begin
                    // Function to lock CPLD in MBC1 mode
                    if (inputData == 7'd0) begin   // If data is 0
                        mbc3or5Locked <= 1'b1;     // Lock in MBC1 mode
                    end
                    else begin
                        romBank <= {1'b0, inputData}; // Store the bank number
                    end
                end
            end
        end
endmodule

